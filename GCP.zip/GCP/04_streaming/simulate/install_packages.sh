#!/bin/bash
sudo python3 -m pip install --upgrade timezonefinder pytz 'apache-beam[gcp]'
