mvn archetype:generate \
      -DarchetypeGroupId=org.apache.beam \
      -DarchetypeArtifactId=beam-sdks-java-maven-archetypes-starter \
      -DarchetypeVersion=2.13.0 \
      -DgroupId=com.google.cloud.training.flights \
      -DartifactId=chapter8_t \
      -Dversion="1.1" \
      -DinteractiveMode=false
