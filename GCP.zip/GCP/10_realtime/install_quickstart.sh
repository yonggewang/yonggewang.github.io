curl -f -O https://github.com/GoogleCloudPlatform/cloud-bigtable-examples/blob/master/quickstart/quickstart.sh
./quickstart.sh
