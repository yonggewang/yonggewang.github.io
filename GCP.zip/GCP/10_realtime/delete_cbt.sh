gcloud beta bigtable instances delete flights
