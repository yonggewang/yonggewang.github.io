gcloud app deploy --quiet --stop-previous-version app.yaml cron.yaml

