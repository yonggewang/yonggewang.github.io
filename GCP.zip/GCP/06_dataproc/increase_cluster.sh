gcloud dataproc clusters update ch6cluster\
   --num-preemptible-workers=3 --num-workers=4
