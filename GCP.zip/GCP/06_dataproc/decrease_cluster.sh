gcloud dataproc clusters update ch6cluster\
   --num-preemptible-workers=0 --num-workers=2

