gcloud dataproc clusters delete ch6cluster
