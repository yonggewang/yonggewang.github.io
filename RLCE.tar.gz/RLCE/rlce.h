/* rlce.h
 * Copyright (C) 2016-2019 Yongge Wang
 * 
 * Yongge Wang
 * Department of Software and Information Systems
 * UNC Charlotte
 * Charlotte, NC 28223
 * yonwang@uncc.edu
 */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include <math.h>

#ifndef _RLCEH_
#define _RLCEH_
typedef unsigned short field_t;
typedef struct {
  char *key;
  int val;
} strvalue_t;
#endif

int rlce_keypair(int crypto_scheme, char* keyfilename);
int rlce_encrypt(int kem, char* pubkey, char* plainfile);
int rlce_decrypt(char* prikey, char* cipherfile);

#define BADCOMMANDLINEFLAG -66
#define genkey128 1
#define genkey192 2
#define genkey256 3
#define enc 4
#define kemenc 5
#define dec 6
