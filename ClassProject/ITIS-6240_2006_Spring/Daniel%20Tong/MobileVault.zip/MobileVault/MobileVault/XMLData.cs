using System;
using System.Collections;
using System.Xml;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;
using System.Text;


namespace MobileVault
{
	/// <summary>
	/// Summary description for XMLData.
	/// </summary>
	/// <summary>
	/// Read and write Data file.
	/// </summary>
	public class XmlData
	{
		// internal fields
		Hashtable _list = new Hashtable();
		string _filePath = "";
		bool _autoWrite = false;
		private string _key = "";
		// properties
		
		/// <summary>
		/// Specifies if the settings file is updated whenever a value 
		/// is set. If false, you need to call Write to update the 
		/// underlying settings file.
		/// </summary>
		public bool AutoWrite
		{
			get { return _autoWrite; }
			set { _autoWrite = value; }
		}

		public string key
		{
			get { return _key; }
			set { 
				
				_key = value; 
				// update settings file
				if (_autoWrite)
					Write();
				}
		}

		/// <summary>
		/// Full path to settings file.
		/// </summary>
		public string FilePath
		{
			get { return _filePath; }
			set { _filePath = value; }
		}

		/// <summary>
		/// Default constructor. 
		/// </summary>
		public XmlData(string inKey, string inDataFile)
		{
			if ( inKey != null && inKey.Length > 0 )
			{
				_key = inKey;
			}

			// get full path to file
			if ( inDataFile != null && inDataFile.Length > 0 )
			{
				_filePath = inDataFile;
			}//if
			else
			{
				_filePath = GetFilePath();
			}//else
			
			// populate list with settings from file
			Read();
		}

		#region Public Method
		// public methods
		
		/// <summary>
		/// Set setting value. Update underlying file if AutoUpdate is true.
		/// </summary>
		public void SetValue(string key, Record value)
		{
			// update internal list
			_list[key] = value;
			
			// update settings file
			if (_autoWrite)
				Write();
		}

		/// <summary>
		/// Remove the record
		/// </summary>
		public void Remove(string key)
		{
			// Remove the record
			_list.Remove(key);
			
			// update settings file
			if (_autoWrite)
				Write();
		}

		/// <summary>
		/// Return specified settings as string.
		/// </summary>
		public Record GetRecord(string key)
		{
			Record result = (Record) _list[key];
			return (result == null) ? null : result;
		}
		
		/// <summary>
		/// Return specified settings as boolean.
		/// </summary>
		public string[] GetNames()
		{
			string[] Names = new string[_list.Count];
			Record objRec;
			int i = 0;

			// go through internal list and create 'add' element for each item
			IDictionaryEnumerator enumerator = _list.GetEnumerator();
			while (enumerator.MoveNext())
			{
				objRec = (Record) enumerator.Value;
				Names[i++]= objRec.RecordName;
			}
		
			return Names;
		}
		/// <summary>
		/// Read settings file.
		/// </summary>
		public void Read()
		{
			XmlDocument xmldoc;
			XmlNode rec;
			XmlNode det;

			// first remove all items from list
			_list.Clear();
				
			// last, populate list with items from file
		
			// open settings file
			if (File.Exists(_filePath))
			{
				Record objRec;
				using (StreamReader sr = new StreamReader(_filePath)) 
				{
					string encXML = sr.ReadToEnd();
					sr.Close();
					//This allows you to do one Read operation.
					xmldoc = new XmlDocument();
					byte[] rawData = Convert.FromBase64String(encXML);
					byte[] resData = Crypto.Decrypt(_key, rawData);
					string rawXml = Encoding.ASCII.GetString(resData, 0, resData.Length);
					xmldoc.LoadXml(rawXml);			
// No Encryption
//					xmldoc.LoadXml(encXML);
				}
				XmlNodeList elemList = xmldoc.DocumentElement.ChildNodes;
				IEnumerator ienum = elemList.GetEnumerator();          
				while (ienum.MoveNext()) 
				{   
					rec = (XmlNode) ienum.Current;
					objRec = new Record();
					objRec.RecordName = rec.Attributes["NAME"].Value;
					
					XmlNodeList detail = (XmlNodeList) rec.ChildNodes;
					IEnumerator idetail = detail.GetEnumerator();
					while (idetail.MoveNext())
					{
						det = (XmlNode) idetail.Current;
						if (det.Name.Equals("ACCOUNT"))
						{
							objRec.Account = det.InnerText;
						}
						if (det.Name.Equals("ACCOUNT_DESC"))
						{
							objRec.AccountDescription = det.InnerText;
						}
						if (det.Name.Equals("NOTES"))
						{
							objRec.Notes = det.InnerText;
						}
						if (det.Name.Equals("PASSWORD"))
						{
							objRec.Password = det.InnerText;
						}
						if (det.Name.Equals("PHONE"))
						{
							objRec.Phone = det.InnerText;
						}
						if (det.Name.Equals("PIN"))
						{
							objRec.Pin = det.InnerText;
						}
						if (det.Name.Equals("URL"))
						{
							objRec.Url = det.InnerText;
						}
						if (det.Name.Equals("USER_ID"))
						{
							objRec.UserID = det.InnerText;
						}
					}
					_list.Add(objRec.RecordName, objRec);
				}//while
			}
		}
		
		/// <summary>
		/// Write settings to the .config file.
		/// </summary>
		public void Write()
		{
			Record objRec;
			string encData;
			StringBuilder bufTemp = new StringBuilder();

			if ( _filePath == null || _filePath.Length == 0 )
			{
				//Data File Path
				SaveFileDialog objFile = new SaveFileDialog();
				if ( objFile.ShowDialog() == DialogResult.OK)
				{
					Settings objSettings = new Settings(Settings.Values);
					objSettings.AutoWrite = true;
				
					_filePath = objFile.FileName;
					objSettings.SetValue("DATA_PATH", _filePath);
				}//if
			}//if
			// header elements
			bufTemp.Append("<?xml version='1.0'?>");
			bufTemp.Append("<ENC_DATA>");

			// go through internal list and create 'add' element for each item
			IDictionaryEnumerator enumerator = _list.GetEnumerator();
			while (enumerator.MoveNext())
			{
				objRec = (Record) enumerator.Value;
				bufTemp.Append("<RECORD NAME='");
				bufTemp.Append(objRec.RecordName);
				bufTemp.Append("'>");
				bufTemp.Append("<ACCOUNT>");
				bufTemp.Append(objRec.Account);
				bufTemp.Append("</ACCOUNT>");
				bufTemp.Append("<PIN>");
				bufTemp.Append(objRec.Pin);
				bufTemp.Append("</PIN>");
				bufTemp.Append("<ACCOUNT_DESC>");
				bufTemp.Append(objRec.AccountDescription);
				bufTemp.Append("</ACCOUNT_DESC>");
				bufTemp.Append("<USER_ID>");
				bufTemp.Append(objRec.UserID);
				bufTemp.Append("</USER_ID>");
				bufTemp.Append("<PASSWORD>");
				bufTemp.Append(objRec.Password);
				bufTemp.Append("</PASSWORD>");
				bufTemp.Append("<PHONE>");
				bufTemp.Append(objRec.Phone);
				bufTemp.Append("</PHONE>");
				bufTemp.Append("<URL>");
				bufTemp.Append(objRec.Url);
				bufTemp.Append("</URL>");
				bufTemp.Append("<NOTES>");
				bufTemp.Append(objRec.Notes);
				bufTemp.Append("</NOTES>");
				bufTemp.Append("</RECORD>");
			}
			bufTemp.Append("</ENC_DATA>");

			byte[] rawData = Encoding.ASCII.GetBytes(bufTemp.ToString());
			byte[] resData = Crypto.Encrypt(_key, rawData);
			encData = Convert.ToBase64String(resData,0, resData.Length);
// No Encryption
//			encData = bufTemp.ToString();
			using (StreamWriter writer = File.CreateText(_filePath))
			{
				writer.Write(encData);
				writer.Close();
			}
		}
		#endregion

		#region Private Methods
		//
		// private methods
		//
		
		/// <summary>
		/// Return full path to settings file. Appends .config to the assembly name.
		/// </summary>
		private string GetFilePath()
		{
			Settings objSettings = new Settings(Settings.Values);
			objSettings.AutoWrite = false;

			return objSettings.GetString("DATA_PATH");
		}
		#endregion
	}
}
