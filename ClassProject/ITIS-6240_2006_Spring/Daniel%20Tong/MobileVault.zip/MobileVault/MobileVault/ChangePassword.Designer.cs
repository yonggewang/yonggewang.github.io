namespace MobileVault
{
    partial class ChangePasswordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.txtNewP1 = new System.Windows.Forms.TextBox();
            this.txtNewP2 = new System.Windows.Forms.TextBox();
            this.txtOldP = new System.Windows.Forms.TextBox();
            this.cmdCancel = new System.Windows.Forms.Button();
            this.cmdChange = new System.Windows.Forms.Button();
            this.inputPanel1 = new Microsoft.WindowsCE.Forms.InputPanel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lbl1);
            this.panel1.Controls.Add(this.txtNewP1);
            this.panel1.Controls.Add(this.txtNewP2);
            this.panel1.Controls.Add(this.txtOldP);
            this.panel1.Controls.Add(this.cmdCancel);
            this.panel1.Controls.Add(this.cmdChange);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(240, 265);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(19, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 20);
            this.label2.Text = "Retype :";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(19, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 20);
            this.label1.Text = "New Password :";
            // 
            // lbl1
            // 
            this.lbl1.Location = new System.Drawing.Point(19, 23);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(88, 20);
            this.lbl1.Text = "old Password :";
            // 
            // txtNewP1
            // 
            this.txtNewP1.AcceptsTab = true;
            this.txtNewP1.Location = new System.Drawing.Point(123, 62);
            this.txtNewP1.Name = "txtNewP1";
            this.txtNewP1.PasswordChar = '*';
            this.txtNewP1.Size = new System.Drawing.Size(88, 21);
            this.txtNewP1.TabIndex = 11;
            // 
            // txtNewP2
            // 
            this.txtNewP2.AcceptsTab = true;
            this.txtNewP2.Location = new System.Drawing.Point(123, 102);
            this.txtNewP2.Name = "txtNewP2";
            this.txtNewP2.PasswordChar = '*';
            this.txtNewP2.Size = new System.Drawing.Size(88, 21);
            this.txtNewP2.TabIndex = 12;
            // 
            // txtOldP
            // 
            this.txtOldP.AcceptsTab = true;
            this.txtOldP.Location = new System.Drawing.Point(123, 22);
            this.txtOldP.Name = "txtOldP";
            this.txtOldP.PasswordChar = '*';
            this.txtOldP.Size = new System.Drawing.Size(88, 21);
            this.txtOldP.TabIndex = 13;
            // 
            // cmdCancel
            // 
            this.cmdCancel.Location = new System.Drawing.Point(139, 143);
            this.cmdCancel.Name = "cmdCancel";
            this.cmdCancel.Size = new System.Drawing.Size(72, 20);
            this.cmdCancel.TabIndex = 14;
            this.cmdCancel.Text = "Cancel";
            this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click_1);
            // 
            // cmdChange
            // 
            this.cmdChange.Location = new System.Drawing.Point(19, 143);
            this.cmdChange.Name = "cmdChange";
            this.cmdChange.Size = new System.Drawing.Size(72, 20);
            this.cmdChange.TabIndex = 15;
            this.cmdChange.Text = "Change";
            this.cmdChange.Click += new System.EventHandler(this.cmdChange_Click_1);
            // 
            // ChangePasswordForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.panel1);
            this.Menu = this.mainMenu1;
            this.Name = "ChangePasswordForm";
            this.Text = "ChangePassword";
            this.Load += new System.EventHandler(this.ChangePasswordForm_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.TextBox txtNewP1;
        private System.Windows.Forms.TextBox txtNewP2;
        private System.Windows.Forms.TextBox txtOldP;
        private System.Windows.Forms.Button cmdCancel;
        private System.Windows.Forms.Button cmdChange;
        public string newPasswd;
        private Microsoft.WindowsCE.Forms.InputPanel inputPanel1;
    }
}