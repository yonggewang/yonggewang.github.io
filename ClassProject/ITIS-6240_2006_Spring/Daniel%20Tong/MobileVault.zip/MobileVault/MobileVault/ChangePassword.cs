using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MobileVault
{
    public partial class ChangePasswordForm : Form
    {
        public ChangePasswordForm()
        {
            InitializeComponent();
        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            newPasswd = "";
            this.Close();
        }

        private void cmdChange_Click(object sender, EventArgs e)
        {
            Settings objSettings = new Settings(Settings.Values);
            objSettings.AutoWrite = true;

            byte[] rawData = Encoding.ASCII.GetBytes(this.txtOldP.Text);
            byte[] resData = Crypto.Encrypt(this.txtOldP.Text, rawData);
            string sEncKey = Convert.ToBase64String(resData, 0, resData.Length);
            string sStoredKey = objSettings.GetString("PASSWORD");

            if (sEncKey.Equals(sStoredKey) && this.txtNewP1.Text.Equals(this.txtNewP2.Text))
            {
                byte[] rawNData = Encoding.ASCII.GetBytes(this.txtNewP1.Text);
                byte[] resNData = Crypto.Encrypt(this.txtNewP1.Text, rawNData);
                objSettings.SetValue("PASSWORD", Convert.ToBase64String(resNData, 0, resNData.Length));
                newPasswd = this.txtNewP1.Text;
                MessageBox.Show("Password Updated!", "Password Updated!", MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);
                this.Close();
            }
            else
            {
                MessageBox.Show("Failed to update password, please try again!", "Failed to update password, please try again!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                this.txtOldP.Text = "";
                this.txtNewP1.Text = "";
                this.txtNewP2.Text = "";
            }
        }

        private void ChangePasswordForm_Load(object sender, EventArgs e)
        {
            this.txtOldP.Focus();
            this.inputPanel1.Enabled = true;
        }

        private void cmdChange_Click_1(object sender, EventArgs e)
        {
            Settings objSettings = new Settings(Settings.Values);
            objSettings.AutoWrite = true;

            byte[] rawData = Encoding.ASCII.GetBytes(this.txtOldP.Text);
            byte[] resData = Crypto.Encrypt(this.txtOldP.Text, rawData);
            string sEncKey = Convert.ToBase64String(resData, 0, resData.Length);
            string sStoredKey = objSettings.GetString("PASSWORD");

            if (sEncKey.Equals(sStoredKey) && this.txtNewP1.Text.Equals(this.txtNewP2.Text))
            {
                byte[] rawNData = Encoding.ASCII.GetBytes(this.txtNewP1.Text);
                byte[] resNData = Crypto.Encrypt(this.txtNewP1.Text, rawNData);
                objSettings.SetValue("PASSWORD", Convert.ToBase64String(resNData, 0, resNData.Length));
                newPasswd = this.txtNewP1.Text;
                MessageBox.Show("Password Updated!", "Password Updated!", MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);
                this.Close();
            }
            else
            {
                MessageBox.Show("Failed to update password, please try again!", "Failed to update password, please try again!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                this.txtOldP.Text = "";
                this.txtNewP1.Text = "";
                this.txtNewP2.Text = "";
            }
        }

        private void cmdCancel_Click_1(object sender, EventArgs e)
        {
            newPasswd = "";
            this.Close();
        }
    }
}