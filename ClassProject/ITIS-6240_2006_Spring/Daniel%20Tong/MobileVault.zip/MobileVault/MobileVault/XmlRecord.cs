using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MobileVault
{
    public partial class XmlRecordForm : Form
    {
        private Record m_record;
        public Record record
        {
            get
            {
                return m_record;
            }
            set
            {
                m_record = value;
            }
        }// Record

        public XmlRecordForm(bool bNew)
        {
            InitializeComponent();

            if (bNew)
            {
                this.txtRecordName.Enabled = true;
            }//if
            else
            {
                this.txtRecordName.Enabled = false;
            }//else
        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            bSaved = false;
            this.Close();
        }

        private void cmdSave_Click(object sender, EventArgs e)
        {
            m_record.RecordName = this.txtRecordName.Text;
            m_record.Account = this.txtAcct.Text;
            m_record.AccountDescription = this.txtDescription.Text;
            m_record.Password = this.txtPassword.Text;
            m_record.Phone = this.txtPhone.Text;
            m_record.Pin = this.txtPin.Text;
            m_record.Url = this.txtUrl.Text;
            m_record.UserID = this.txtUserID.Text;
            m_record.Notes = this.txtNotes.Text;
            bSaved = true;
            this.Close();
        }

        private void XmlRecordForm_Load(object sender, EventArgs e)
        {
            if (m_record != null)
            {
                this.txtRecordName.Text = m_record.RecordName;
                this.txtAcct.Text = m_record.Account;
                this.txtDescription.Text = m_record.AccountDescription;
                this.txtPassword.Text = m_record.Password;
                this.txtPhone.Text = m_record.Phone;
                this.txtPin.Text = m_record.Pin;
                this.txtUrl.Text = m_record.Url;
                this.txtUserID.Text = m_record.UserID;
                this.txtNotes.Text = m_record.Notes;
            }//if
            else
            {
                m_record = new Record();
            }//else
            this.inputPanel1.Enabled = true;
        }

        private void cmdSave_Click_1(object sender, EventArgs e)
        {
            m_record.RecordName = this.txtRecordName.Text;
            m_record.Account = this.txtAcct.Text;
            m_record.AccountDescription = this.txtDescription.Text;
            m_record.Password = this.txtPassword.Text;
            m_record.Phone = this.txtPhone.Text;
            m_record.Pin = this.txtPin.Text;
            m_record.Url = this.txtUrl.Text;
            m_record.UserID = this.txtUserID.Text;
            m_record.Notes = this.txtNotes.Text;
            bSaved = true;
            this.Close();
        }

        private void cmdCancel_Click_1(object sender, EventArgs e)
        {
            bSaved = false;
            this.Close();
        }

        private void XmlRecordForm_Closing(object sender, CancelEventArgs e)
        {
            this.inputPanel1.Enabled = false;
        }

        private void inputPanel1_EnabledChanged(object sender, EventArgs e)
        {
            try
            {

                if (this.inputPanel1.Enabled)
                {
                    this.panel1.ClientSize = this.ClientSize;
                    this.panel1.Height -= inputPanel1.Bounds.Height;
                }
                else
                {
                    this.panel1.ClientSize = this.ClientSize;
                }
            }
            catch
            {
            }

        }
    }
}