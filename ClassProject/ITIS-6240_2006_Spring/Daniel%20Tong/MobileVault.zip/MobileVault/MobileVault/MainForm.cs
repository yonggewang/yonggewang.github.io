using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace MobileVault
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void menuItem9_Click(object sender, EventArgs e)
        {
            //About
            AboutForm dlgAbout = new AboutForm();
            dlgAbout.ShowDialog();
            this.ShowDialog();
        }

        private void loadList()
        {
            this.lstNames.Items.Clear();

            string[] arNames = objXmlData.GetNames();
            for (int i = 0; i < arNames.Length; i++)
            {
                this.lstNames.Items.Add(arNames[i]);
            }

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.Menu = mainMenu;
            if (m_key == null || m_key.Length == 0)
            {
                this.Hide();
                LoginForm dlgLogin = new LoginForm();
                dlgLogin.ShowDialog();
                if (dlgLogin.bLogined)
                {
                    m_key = dlgLogin.txtPassword.Text;
                    dlgLogin.Dispose();
                    objXmlData = new XmlData(m_key, m_dataFile);
                    loadList();
                    this.ShowDialog();
                }
                else
                {
                    this.Close();
                }
            }
        }

        private void menuItem10_Click(object sender, EventArgs e)
        {
            // New
            XmlRecordForm dlgXmlRecord = new XmlRecordForm(true);
            dlgXmlRecord.ShowDialog();
            if (dlgXmlRecord.bSaved)
            {
                objXmlData.AutoWrite = true;
                objXmlData.SetValue(dlgXmlRecord.record.RecordName, dlgXmlRecord.record);
                MessageBox.Show("Record Saved.", "Record Saved", MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);
            }//if
            dlgXmlRecord.Dispose();
            loadList();
        }

        private void menuItem7_Click(object sender, EventArgs e)
        {
            // Change password
            ChangePasswordForm dlgChangePw = new ChangePasswordForm();
            dlgChangePw.ShowDialog();
            if (dlgChangePw.newPasswd != "")
            {
                objXmlData.AutoWrite = true;
                objXmlData.key = dlgChangePw.newPasswd;
            }
        }

        private void menuItem2_Click(object sender, EventArgs e)
        {
            // Data Path
            SaveFileDialog objFile = new SaveFileDialog();
            if (objFile.ShowDialog() == DialogResult.OK)
            {
                Settings objSettings = new Settings(Settings.Values);
                objSettings.AutoWrite = true;

                m_dataFile = objFile.FileName;
                objXmlData.FilePath = m_dataFile;
                objSettings.SetValue("DATA_PATH", m_dataFile);
            }//if
            this.ShowDialog();
        }

        private void menuItem3_Click(object sender, EventArgs e)
        {
            //Backup File Path
            SaveFileDialog objFile = new SaveFileDialog();
            if (objFile.ShowDialog() == DialogResult.OK)
            {
                Settings objSettings = new Settings(Settings.Values);
                objSettings.AutoWrite = true;

                m_dataFile = objFile.FileName;
                objXmlData.FilePath = m_dataFile;
                objSettings.SetValue("BACKUP_PATH", m_dataFile);
            }//if
            this.ShowDialog();		
        }

        private void menuItem5_Click(object sender, EventArgs e)
        {
            // Exit
            DialogResult dlgRes = MessageBox.Show("Do you want to backup data file?", "Do you want to backup data file?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);

            if (dlgRes == DialogResult.Yes)
            {
                Settings objSettings = new Settings(Settings.Values);
                // Perform Backup
                File.Copy(objSettings.GetString("DATA_PATH"), objSettings.GetString("BACKUP_PATH"), true);
            }//if

            if (dlgRes != DialogResult.Cancel)
            {
                // Exit
                this.Close();
                this.Dispose(true);
            }//if
        }

        private void lstNames_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Edit
            Record objRec = objXmlData.GetRecord(this.lstNames.SelectedItem.ToString());
            XmlRecordForm dlgXmlRecord = new XmlRecordForm(false);
            dlgXmlRecord.record = objRec;
            dlgXmlRecord.ShowDialog();
            if (dlgXmlRecord.bSaved)
            {
                objXmlData.AutoWrite = true;
                objXmlData.SetValue(dlgXmlRecord.record.RecordName, dlgXmlRecord.record);
                MessageBox.Show("Record Saved.", "Record Saved", MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);
            }//if
            dlgXmlRecord.Dispose();
            loadList();
        }

        private void menuItem11_Click(object sender, EventArgs e)
        {
            // Delete
            objXmlData.Remove(this.lstNames.SelectedItem.ToString());
            loadList();
        }
    }
}