using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MobileVault
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            this.inputPanel1.Enabled = true;

        }

        private void cmdLogin_Click(object sender, EventArgs e)
        {
            Settings objSettings = new Settings(Settings.Values);
            objSettings.AutoWrite = true;

            byte[] rawData = Encoding.ASCII.GetBytes(this.txtPassword.Text);
            byte[] resData = Crypto.Encrypt(this.txtPassword.Text, rawData);
            string sEncKey = Convert.ToBase64String(resData, 0, resData.Length);
            string sStoredKey = objSettings.GetString("PASSWORD");

            if (sEncKey.Equals(sStoredKey))
            {
                bLogined = true;
                this.Close();
            }
            else
            {
                iCount++;
                MessageBox.Show("Incorrect Password", "Incorrect Password", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                this.txtPassword.Text = "";
                bLogined = false;
                if (iCount > 2)
                {
                    this.Close();
                }
            }
        }

        private void inputPanel1_EnabledChanged(object sender, EventArgs e)
        {
            try
            {
                if (this.inputPanel1.Enabled)
                {
                    this.panel1.ClientSize = this.ClientSize;
                    this.panel1.Height -= inputPanel1.Bounds.Height;
                }
                else
                {
                    this.panel1.ClientSize = this.ClientSize;
                }
            }
            catch
            {
            }
        }
    }
}