using System;

namespace MobileVault
{
	/// <summary>
	/// Summary description for Record.
	/// </summary>
	public class Record
	{
		public Record()
		{
		}

		private string m_recordname;
		public string RecordName
		{
			get
			{
				return m_recordname;
			}
			set
			{
				m_recordname = value;
			}
		}// RecordName

		private string m_acctnumber;
		public string Account
		{
			get
			{
				return m_acctnumber;
			}
			set
			{
				m_acctnumber = value;
			}
		}// Account

		private string m_acctdesc;
		public string AccountDescription
		{
			get
			{
				return m_acctdesc;
			}
			set
			{
				m_acctdesc = value;
			}
		}// AccountDescription

		private string m_userID;
		public string UserID
		{
			get
			{
				return m_userID;
			}
			set
			{
				m_userID = value;
			}
		}// UserID
		
		private string m_password;
		public string Password
		{
			get
			{
				return m_password;
			}
			set
			{
				m_password = value;
			}
		}// Password

		private string m_pin;
		public string Pin
		{
			get
			{
				return m_pin;
			}
			set
			{
				m_pin = value;
			}
		}// Pin

		private string m_url;
		public string Url
		{
			get
			{
				return m_url;
			}
			set
			{
				m_url = value;
			}
		}// Url

		private string m_phone;
		public string Phone
		{
			get
			{
				return m_phone;
			}
			set
			{
				m_phone = value;
			}
		}// Phone

		private string m_notes;
		public string Notes
		{
			get
			{
				return m_notes;
			}
			set
			{
				m_notes = value;
			}
		}// Notes
	}
}
