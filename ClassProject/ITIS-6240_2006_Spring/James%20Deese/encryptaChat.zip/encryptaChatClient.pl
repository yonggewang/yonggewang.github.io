#!/usr/bin/perl -w

use strict;
use IO::Socket;
use Crypt::GCrypt;
use MIME::Base64;

my ($childpid, $handle, $line);
my $port = "6667";
my $counter = 0;
my $plaintext = "";
my $decryptme = "";
my $encryptedusername = "";

#build GCrypt object for symmetric cipher
my $encryptor = Crypt::GCrypt->new(
	type 		=> 'cipher',
	algorithm 	=> 'aes',
	mode 		=> 'cbc',
	padding		=> 'standard'
	);
my $decryptor = Crypt::GCrypt->new(
	type		=> 'cipher',
	algorithm	=> 'aes',
	mode 		=> 'cbc',
	);
# ask for user name
print "please provide a user name:  ";
my $usernameinput = <STDIN>;
chomp($usernameinput);
my $username = $usernameinput . " says";
print "please provide the IP address of the EncryptaChatServer:  ";
my $host = <STDIN>;
chomp($host);
# create a tcp connection to the specified host and port
$handle = IO::Socket::INET->new(Proto     => "tcp",
                                PeerAddr  => $host,
                                PeerPort  => $port)
       or die "can't connect to port $port on $host: $!";

$handle->autoflush(1);              # so output gets there right away
print STDERR "[Connected to $host:$port]\n";
print "Please press enter to begin chat session\n";

# split the program into two processes, identical twins
die "can't fork: $!" unless defined($childpid = fork());

if ($childpid) {                     
    # parent copies the socket to standard output
    while (defined ($line = <$handle>)) {
	$decryptor->start('decrypting');
	$decryptor->setkey('password');
	$decryptme = decode_base64($line);
	$plaintext = $decryptor->decrypt($decryptme);
	print "Encrypted Text:\n";
	print $line;
	print "Plain Text:\n";
	print STDOUT $plaintext;
    }
    kill("TERM" => $childpid);        # send SIGTERM to child
}
else {                              
    # child copies standard input to the socket
    while (defined ($line = <STDIN>)) {
    	#encrypt stdin
	$encryptor->start('encrypting');
	$encryptor->setkey('password');
	if ($counter == 0){
		$encryptedusername = $encryptor->encrypt($usernameinput . " has entered EncryptaChat\n\n");
		$encryptedusername .= $encryptor->finish;
		print $handle encode_base64($encryptedusername);
		$counter++;
	}
	else{
	my $ciphertext = $encryptor->encrypt("$username : $line\n");
	$ciphertext .= $encryptor->finish;
        print $handle encode_base64($ciphertext);
    	}
    }
}
exit;
