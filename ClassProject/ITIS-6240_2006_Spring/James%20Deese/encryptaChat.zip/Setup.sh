#!/bin/sh

cpan install IO::Socket && cpan install Crypt::GCrypt && cpan install MIME::Base64 && cpan install POE && cpan install POE::Component::Server::TCP
