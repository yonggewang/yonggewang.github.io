

********************************************************************************
				EncryptaChat

Description:
--------------------

This is EncryptaChat, a chat server with associated clients.  It has been
developed as a means to have a fully encrypted group chat session over IP.  It
uses AES encryption along with CBC mode.  EncryptaChatServer uses the POE
module, a portable multitasking and networking framework for Perl.  The server
handles multiple clients sending it encrypted text and broadcasts that
ciphertext to all clients connected in a session.  EncryptaChatClient simple
uses the IO::Socket module for its communication with the server.  It also
incorporates the Crypt::GCrypt module for interfacing with the GCrypt C
library.  Finally, the MIME::Base64 module is used to wrap any encrypted data
to be sent over the network.

Requirements:
--------------------
EncryptaChat requires Perl to be installed in order to build and run.
EncryptaChat was built and installed using perl, v5.8.7 built for i686-linux.
More information on perl can be found at http://www.perl.org/ .  Several perl
modules are also required in order to run EncryptaChat:

IO::Socket
Crypt::GCrypt
MIME::Base64
POE
POE::Component::Server::TCP

These modules can be installed using Cpan or done manually.  Included within
the EncryptaChat package is a Setup.sh file that will run Cpan for you
automatically and install all required packages.

Installation:
--------------------
Run the Setup.sh script:

	./Setup.sh

The Setup script will run cpan for each required perl module called from
EncryptaChat.

Running EncryptaChat
--------------------
Once the modules are loaded you are ready to start the EncryptaChatServer:

	./EncryptaChatServer &

The & will run the process in the background as a daemon.  The server only
needs to run on one machine.  All clients connect to the same server.

Next, each client needs to connect to the server by running:

	./EncryptaChatClient

You will then be prompted for a user name, type one in and press enter.  Next,
you will be asked to provide an IP address of the EncryptaChatServer.  This is
the address where the EncryptaChatServer Daemon is running.  If successful, a
Connected to "IP address:port" will show and you will be asked to press enter
to begin the chat session.  After pressing enter, you are ready to start
sending messages to other clients.  

Future Work
--------------------
At this time the interface is only at a console.  To keep the server from
unencrypting any data and letting only clients do such, what you type in is
duplicated on the console making for a messy look.  Future work includes
building a front end GUI for EncryptaChat that would make for a nice
representation for the user.

As a proof of concept, I have added in the encrypted message along with the
plaintext in order to show how it works.
