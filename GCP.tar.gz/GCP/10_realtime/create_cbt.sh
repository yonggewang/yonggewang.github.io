gcloud beta bigtable instances create flights --cluster=datascienceongcp --cluster-zone=us-central1-b --display-name="Chapter 10" --instance-type=DEVELOPMENT
