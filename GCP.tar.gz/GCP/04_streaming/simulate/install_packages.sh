#!/bin/bash
sudo python3 -m pip install --upgrade timezonefinder pytz 'apache-beam[gcp]'

## Note: if this script fails, try running the command above without "sudo"
